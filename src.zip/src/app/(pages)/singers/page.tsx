import Section1 from "./Section1";

export default function SingerDetail() {
  return (
    <>
      <Section1 />
    </>
  );
}
