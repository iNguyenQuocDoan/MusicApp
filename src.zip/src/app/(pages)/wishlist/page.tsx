import Section1 from "./Section1";

export default function WishList() {
  return (
    <>
      <Section1 />
    </>
  );
}
