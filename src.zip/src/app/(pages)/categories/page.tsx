import Section1 from "./Section1";

export default function CategoriesPage() {
  return (
    <>
      {/* Section1 */}
      <Section1 />
      {/* Section1 end */}
    </>
  );
}
