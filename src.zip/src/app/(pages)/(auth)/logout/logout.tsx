export default function Logout() {
  return (
    <>
      <h1 className="text-[32] font-[700]"> Trang Logout</h1>
    </>
  );
}
